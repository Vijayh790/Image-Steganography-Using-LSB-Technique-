#ifndef DECODE_H          // checks whether DECODE_H is not defined
#define DECODE_H          // defines DECODE_H to avoid multiple inclusion

#include <stdio.h>        // header file is used for file handling functions
#include "types.h"       // header file contains user defined types

// structure stores all decoding related information
typedef struct _DecodeInfo   
{
    char *stego_image_fname;     // pointer stores the stego image file name
    FILE *fptr_stego_image;      // file pointer is used to access stego image file
 
    char output_fname[100];      // array stores the output file name
    FILE *fptr_output;           // file pointer is used to create output file

    int  extn_size;              // variable stores the size of file extension
    char extn[MAX_FILE_SUFFIX];  // array stores the decoded file extension

    long file_size;              // variable stores the decoded secret file size

    char magic[MAX_MAGIC_LEN];   // array stores the decoded magic string

} DecodeInfo;                   // creates alias name for structure

// function validates decode command line arguments
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo);

// function opens required files for decoding
Status open_decode_files(DecodeInfo *decInfo);

// function performs complete decoding process
Status do_decoding(DecodeInfo *decInfo);

// function decodes one byte from LSB bits
void decode_byte_from_lsb(char *data, FILE *fptr); 

// function decodes integer value from LSB bits
void decode_int_from_lsb_int(int *data, FILE *fptr);  

// function decodes long value from LSB bits
void decode_int_from_lsb_long(long *data, FILE *fptr);  

// function removes extension from file name
void remove_extn(char *fname);                           

#endif  // This line ends the header guard