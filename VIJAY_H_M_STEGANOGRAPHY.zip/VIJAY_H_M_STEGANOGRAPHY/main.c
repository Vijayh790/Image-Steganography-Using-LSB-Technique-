/*
Name : VIJAY H M

Name of the project : Image Steganography using LSB Technique

Date : 05/05/2026

Batch name : int-26001B

Project Description :

This project implements Image Steganography using the Least Significant Bit (LSB) technique in the C programming language. 
The system allows users to securely hide a secret text file inside a BMP image and later retrieve it without visibly altering the image.

The main objective of this project is to:

Hide confidential data inside an image file
Ensure data security using a magic string verification
Retrieve the hidden data accurately without loss

Encoding (Hiding Data) :

A BMP image is taken as input
A secret text file is read
Data is hidden inside the image by modifying the least significant bits of pixel values
The following data is embedded:
Magic string (for verification)
File extension
File size
Actual file content

The output is a stego image, which looks identical to the original.

Decoding (Extracting Data) :

The stego image is read
Hidden bits are extracted using the same LSB logic
Magic string is verified
File extension and size are decoded
Original file is reconstructed

Key Features : 

Uses LSB technique (invisible to human eye)
Supports .bmp images only
Ensures data integrity using magic string
Handles file size and extension dynamically
Provides proper error handling and validation
Command-line based execution

Applications :

Secure communication
Digital watermarking
Data hiding in images
Cybersecurity applications
*/

// Header files
#include <stdio.h>              
#include "encode.h"             
#include "types.h"              
#include <string.h>             
#include "decode.h"  

// MACROS for colour
#define RED     "\033[1;91m"    // Bright Red
#define GREEN   "\033[1;92m"    // Bright Green
#define YELLOW  "\033[1;93m"    // Bright Yellow
#define RESET   "\033[0m"       // Reset colour


// This is the main function where execution starts
int main(int argc, char *argv[])   
{
    if(check_operation_type(argv)==e_encode)   // Check if user selected encoding option
    {
        printf(YELLOW "You choosed encoding\n"RESET);   // Print encoding message

        EncodeInfo encInfo;   // Create structure variable for encoding

        if(read_and_validate_encode_args(argv, &encInfo)==e_success)   // Validate encode arguments
        {
            printf("Read and validate successfull\n");   // Print success message

            if(do_encoding(&encInfo)==e_success)   // Perform encoding process
            {
                printf(GREEN "Encoding successfull\n" RESET );   // Print encoding success
                return e_success;   // Return success
            }
        }
        else
        {
            printf("Read and validate unsuccessfull\n");   // Print validation failure
        }
        return e_success;   // Return success even if encoding fails internally
    }
    else if(check_operation_type(argv)==e_decode)   // Check if user selected decoding option
    {
        printf(YELLOW "You choosed decoding\n"RESET);   // Print decoding message

        DecodeInfo decInfo;   // Create structure variable for decoding

        if(read_and_validate_decode_args(argv, &decInfo) == e_success)   // Validate decode arguments
        {
            printf("Read and validate successfull\n"); 

            if(do_decoding(&decInfo) == e_success)   // Perform decoding process
            {
                printf(GREEN "Decoding successful\n" RESET);   // Print decoding success
            }
            else
            {
                printf(RED "Decoding failed\n" RESET);   // Print decoding failure
            }
        }
        else
        {
            printf(RED "Read and validate unsuccessfull\n" RESET);   // Print invalid argument message
        }

        return e_success;   // Return success after decoding flow
    }
    else   // If neither encoding nor decoding option is selected
    {
        printf("Error: Missing arguments\n");
        printf("Usage:\n");
        printf("Decoding : ./a.out -d <stego.bmp> [output file]\n");
        return e_failure;
    }
}

// This function checks whether user selected encode or decode
OperationType check_operation_type(char *argv[])   
{
    if(strcmp(argv[1], "-e")==0)   // Compare argument with "-e"
    {
        return e_encode;   // Return encode operation type
    }
    else if(strcmp(argv[1], "-d")==0)   // Compare argument with "-d"
    {
        return e_decode;   // Return decode operation type
    }
    else
    {
        return e_unsupported;   // Return unsupported operation if input is invalid
    }
}