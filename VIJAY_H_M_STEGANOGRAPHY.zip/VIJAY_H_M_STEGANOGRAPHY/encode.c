// Header files
#include<stdio.h>
#include<string.h>
#include "encode.h"
#include "types.h"

// MACRO for colour
#define YELLOW  "\033[1;93m"  // Bright yellow
#define RESET   "\033[0m"     // reset colour

// This function reads and validates command line arguments for encoding
Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
    // Check minimum required arguments 
    if (argv[2] == NULL || argv[3] == NULL)
    {
        // Print error message if arguments are not provided
        printf("Error: Missing arguments\n");
        printf("Usage:\n");
        printf("Encoding : ./a.out -e input.bmp secret.txt stego.bmp\n");
        return e_failure;  // Return failure
    }

    if (strstr(argv[2], ".bmp") != NULL)  // Check if input file is a .bmp image
    {
        encInfo->src_image_fname = argv[2]; // Store input image file name
        
        printf("Input image validated (.bmp)\n");  // Print validation success
    }
    else
    {
        printf("Error: Input image must be a .bmp file\n"); // Print error if file is not BMP
        return e_failure;
    }

    if (strstr(argv[3], ".txt") != NULL) // Check if secret file is a .txt file
    {
        encInfo->secret_fname = argv[3];  // Store secret file name

        printf("Secret file validated (.txt)\n"); // Print validation success
    }
    else
    {
        printf("Error: Secret file must be a .txt file\n"); // Print error if file is not TXT
        return e_failure;
    }

    if (argv[4] != NULL) // Check if output file is provided
    {
        if (strstr(argv[4], ".bmp") != NULL) // Validate output file extension
        {
            encInfo->stego_image_fname = argv[4];  // Store output stego image name

            printf("Output image: %s\n", argv[4]);  // Print output file name
        }
        else
        {
            printf("Error: Output file must be .bmp format\n");   // Print error if output is not BMP
            return e_failure;
        }
    }
    else
    {
        encInfo->stego_image_fname = "stego.bmp"; // Assign default output file name

        printf("Output image not provided. Using default: stego.bmp\n");  // Inform user about default output
    }

    // Return success after validation
    return e_success;
}

// This function performs the complete encoding process step by step
Status do_encoding(EncodeInfo *encInfo)
{
    printf(YELLOW "<<<------------Stared doing encoding--------------->>>>\n" RESET);  // Print starting message in yellow color
    
    if( open_files(encInfo) == e_success)  // Open source image, secret file and output stego file
    {
        printf("All files opened successfully\n");   // Print success message if all files are opened
    }
    else
    {
        printf("All files did not opened successfully\n"); // Print error if any file fails to open
        
        return e_failure;  // Return failure
    }

    printf("Enter magic string: "); // Ask user to enter magic string
    scanf(" %[^\n]",encInfo -> magic);  // Read magic string including spaces

     // Check whether image has enough capacity to store data
    if(check_capacity(encInfo)== e_success)
    {
        printf("Capacity checked Successfully\n"); // Print success if capacity is sufficient
    }
    else
    {
        printf("Capacity of the srce file is less\n"); // Print error if capacity is insufficient
        return e_failure;
    }

     // Copy first 54 bytes (BMP header) to output image
    if(copy_bmp_header(encInfo->fptr_src_image,encInfo->fptr_stego_image) == e_success)
    {
        printf("Header copied successfully\n");  // Print success message
    }
    else
    {
        printf("Header not copied sucessfully\n");  // Print error message
        return e_failure;
    }
     
     // Encode magic string into image
    if(encode_magic_string(encInfo->magic,encInfo) == e_success)
    {
        printf("Magic string encoded successfull\n"); // Print success message
    }
    else
    {
        printf("Magic string did not encoded successfully\n");   // Print error message
        return e_failure;
    }

    // Encode size of secret file extension
    if(encode_secret_file_extn_size(strlen(strchr(encInfo->secret_fname, '.')), encInfo) == e_success)
    {
        printf("Size of secret extn file encoded successfully\n");  // Print success message
    }
    else
    {
        printf("Size of secret extn file not encoded successfully\n"); // Print error message

        return e_failure;
    }

     // Encode secret file extension (.txt)
    if(encode_secret_file_extn( strchr(encInfo->secret_fname,'.'),encInfo) == e_success)
    {
        printf("Secret extn encoded successfully\n");  // Print success message
    }
    else
    {
        printf("Secret extn not encoded successfully\n");  // Print error message
        return e_failure;
    }

    // Encode size of secret file
    if(encode_secret_file_size(encInfo->size_secret_file, encInfo) == e_success)
    {
        printf("Secret file size encoded successfully\n"); // Print success message
    }
    else
    {
        printf("Secret file size not encoded successfully\n"); // Print error message
        return e_failure;
    }

    // Encode actual secret file data
    if(encode_secret_file_data(encInfo) == e_success)
    {
        printf("Secret data encoded successfully\n");  // Print success message
    }
    else
    {
        printf("Secret data not encoded successfully\n");   // Print error message
        return e_failure;
    }

     // Copy remaining image data after encoding
    if(copy_remaining_img_data(encInfo->fptr_src_image, encInfo->fptr_stego_image) == e_success)
    {
        printf("Remaining data copied successfully\n"); // Print success message
    }
    else
    {
        printf("Remaining data not copied successfully\n");  // Print error message
        return e_failure;
    }

    return e_success;  // Return success after complete encoding
}

// This function opens source image, secret file and stego output file
Status open_files(EncodeInfo *encInfo)
{
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r"); // Open source image file in read mode

    if(encInfo->fptr_src_image == NULL)  // Check if source image failed to open
    {
        printf("Source file is not opened\n"); // Print error
        return e_failure;
    }
    else
    {
        printf("Source file is opened\n"); // Print success message
    }

    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");  // Open secret file in read mode

    if(encInfo->fptr_secret == NULL) // Check if secret file failed
    {
        printf("Secret file is not opened\n");
        return e_failure;
    }
    else
    {
        printf("Secret file is opened\n");
    }

    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "w"); // Open output stego file in write mode

    if(encInfo->fptr_stego_image == NULL) // Check if output file failed
    {
        printf("Stego file is not opened\n");
        return e_failure;
    }
    else
    {
        printf("Stego file is opened\n");
    }

    // Return success if all files opened
    return e_success;
}

// This function checks whether the image has enough capacity to store secret data
Status check_capacity(EncodeInfo *encInfo)
{
   encInfo->image_capacity = get_image_size_for_bmp(encInfo->fptr_src_image);   // Get total image capacity (in bytes)
   printf("Image Capacity = %u\n",encInfo->image_capacity); // Print image capacity

   encInfo->size_secret_file = get_file_size(encInfo-> fptr_secret);  // Get size of secret file
   printf("Secrert file size = %lu\n",encInfo->size_secret_file);  // Print secret file size

    // Check if image can store magic string, extension, size and data
   if(encInfo->image_capacity > (strlen(encInfo->magic) * 8+32+32+32 + encInfo->size_secret_file * 8 ))
   {
        return e_success;  // Return success if capacity is sufficient
   }
   else
   {
    return e_failure;  // Return failure if capacity is insufficient
   }
}

// This function calculates total size of BMP image using width and height
uint get_image_size_for_bmp(FILE *fptr_image)
{
    int wid , len; // Variables to store width and height

    fseek(fptr_image,18,SEEK_SET); // Move file pointer to width position in BMP header

    fread(&wid,4,1,fptr_image);  // Read width (4 bytes)
    
    fread(&len,4,1,fptr_image);  // Read height (4 bytes)

    // Return total image size (width × height × 3 bytes for RGB)
    return wid*len*3;
}

// This function returns the size of the given file
uint get_file_size(FILE *fptr)
{
    fseek(fptr,0,SEEK_END);  // Move file pointer to end of file
    
    return ftell(fptr);  // Return current position which is file size
}

// This function copies first 54 bytes (BMP header) from source to destination image
Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image)
{
    rewind(fptr_src_image);  // Move file pointer to beginning of source image

    char buffer[54]; // Buffer to store header data
    
    fread(buffer,54,1,fptr_src_image);  // Read 54 bytes from source image
    
    fwrite(buffer,54,1,fptr_dest_image); // Write 54 bytes to destination image

    return e_success;  // Return success
}

// This function encodes the magic string into the image
Status encode_magic_string(char *magic_string, EncodeInfo *encInfo)
{
    // Encode magic string using LSB technique
    if(encode_data_to_image(magic_string,strlen(magic_string),encInfo)== e_success)
    {
        printf("Magic encoded\n"); // Print success message
        return e_success;
    }
    else
    {
        printf("Magic not encoded\n"); // Print failure message
        return e_failure;
    }
}

// This function encodes data into image using LSB technique
Status encode_data_to_image(char *data, int size, EncodeInfo *encoInfo)
{
    char buffer[8]; // Buffer to store 8 bytes from image
   
    for(int i=0;i<size;i++)  // Loop through each byte of data
    {
        fread(buffer,8,1,encoInfo->fptr_src_image);   // Read 8 bytes from source image

        encode_byte_to_lsb(data[i], buffer); // Encode one byte into 8 bytes using LSB

        fwrite(buffer,8,1,encoInfo->fptr_stego_image);  // Write modified bytes into stego image
    }

    // Return success after encoding all data
    return e_success;
}

// This function encodes one byte into LSB of 8 image bytes
Status encode_byte_to_lsb(char data, char *image_buffer)
{
    for(int i = 0; i < 8; i++) // Loop through 8 bits of the character
    {
        int bit = (data >> (7 - i)) & 1; // Extract each bit from MSB to LSB

        image_buffer[i] = (image_buffer[i] & 0xFE) | bit; // Replace LSB of image byte with extracted bit
    }
    return e_success;  // Return success
}

// This function encodes the size of the secret file extension into the image
Status encode_secret_file_extn_size(int data, EncodeInfo *encInfo)
{
    // Call function to encode integer using LSB technique
    if(encode_int_to_lsb(data, encInfo) == e_success)
       return e_success; // Return success if encoding is successful
    else 
       return e_failure;  // Return failure if encoding fails
}

// This function encodes a 32-bit integer into the image using LSB technique
Status encode_int_to_lsb(int data, EncodeInfo *encInfo)
{
    char buffer[32]; // Buffer to store 32 bytes from image

    fread(buffer, 32, 1, encInfo->fptr_src_image);  // Read 32 bytes from source image

    // Loop through each bit of integer (32 bits)
    for(int i=31; i>=0; i--)
        // Extract each bit and replace LSB of image byte
        buffer[31-i] = ((data & (1 << i)) >> i) | (buffer[31-i] & 0xFE);

    fwrite(buffer, 32, 1, encInfo->fptr_stego_image); // Write modified bytes into stego image

    return e_success;  // Return success
}

// This function encodes the secret file extension (like .txt) into the image
Status encode_secret_file_extn(char *file_extn, EncodeInfo *encInfo)
{
    // Encode extension string using LSB technique
    if(encode_data_to_image(file_extn, strlen(file_extn), encInfo)== e_success)
        return e_success; // Return success if encoding is successful
    else 
        return e_failure; // Return failure if encoding fails
}

// This function encodes the size of the secret file into the image
Status encode_secret_file_size(long file_size, EncodeInfo *encInfo)
{
    if(encode_int_to_lsb(file_size, encInfo) == e_success) // Encode file size using LSB technique
       return e_success;  // Return success if encoding is successful
    else 
       return e_failure; // Return failure if encoding fails
}

// This function encodes the actual content of the secret file into the image
Status encode_secret_file_data(EncodeInfo *encInfo)
{
    rewind(encInfo->fptr_secret);   // Move file pointer to beginning of secret file

    char buffer[encInfo->size_secret_file];   // Buffer to store secret file data

    fread(buffer, encInfo->size_secret_file, 1, encInfo->fptr_secret);  // Read entire secret file into buffer

     // Encode file data into image using LSB technique
    return encode_data_to_image(buffer, encInfo->size_secret_file, encInfo);
}

// This function copies remaining image data after encoding is complete
Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest)
{
    char ch; // Variable to store one byte

    // Read one byte at a time until end of file
    while(fread(&ch, 1, 1, fptr_src))
    {
        fwrite(&ch, 1, 1, fptr_dest);  // Write the byte to destination image
    }

    return e_success;  // Return success after copying remaining data
}